import pandas as pd
df = pd.read_csv('/restaurant-django/dish/restaurants_small.csv')
df.head()

print(df)