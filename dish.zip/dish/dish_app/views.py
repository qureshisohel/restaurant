from django.shortcuts import render
from dish_app.models import Dish
# Create your views here.
def search(request):
    query = request.GET.get('query')
    results =[]
    if query:
        results = Dish.objects.filter(name__icontains=query)
        
    return render(request,'dish_app/dish_sear.html',{'query':query,'results':results})

def my_view(request):
    lists = MyModel.objects.all()
    return render(request, 'dish_app/my_template.html', {'lists': lists})