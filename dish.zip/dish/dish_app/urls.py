from django.urls import path
from dish_app.views import search,my_view
#from dish_app import views

urlpatterns = [
    path('',search,name='search'),
    path('my-view/', my_view, name='my-view'),
]