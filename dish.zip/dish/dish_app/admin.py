from django.contrib import admin
from dish_app.models import Dish
#from .models import *
from import_export.admin import ImportExportModelAdmin
# Register your models here.

class DishAdmin(ImportExportModelAdmin,admin.ModelAdmin):
    admin.site.register(Dish)

"""
@admin.register(Dish)
class ViewAdmin(ImportExportModelAdmin):
    pass
"""
